# Telegram Bot with Email Verification and Admin Panel

## 🛠 Technologies
- Python
- python-telegram-bot
- Flask (for admin panel)

## ⚙️ Environment Variables
- BOT_TOKEN
- SMTP_EMAIL
- SMTP_PASSWORD
- ADMIN_USER_ID
- ADMIN_PASSWORD

## 🚀 How to Deploy on Render

### Web Service:
- Start Command: `python admin_panel.py`
- Add `ADMIN_PASSWORD` in Environment

### Background Worker:
- Start Command: `python main_bot.py`
- Add the other variables (BOT_TOKEN, etc.)

Visit your admin panel with:
https://your-app-name.onrender.com/?password=your_admin_password
