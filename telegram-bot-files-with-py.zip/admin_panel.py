from flask import Flask, request
from main_bot import get_registered_data
import os

app = Flask(__name__)
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")

@app.route("/")
def home():
    password = request.args.get("password")
    if password != ADMIN_PASSWORD:
        return "Unauthorized"
    users = get_registered_data()
    return "<br>".join([f"{uid}: {data['email']}" for uid, data in users.items()])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
